import React from 'react'
import { useState } from 'react';
const Contact = () => {
const [data, setData] = useState({
    fullname: '',
    phone: '',
    email: '',
    message:'',
});


const InputEvent = (event) => {
const {name, value} = event.target;

setData((preVal) => {
return {
    ...preVal,
    [name] : value,
};
});
};

const formSubmit = (e) =>{
e.preventDefault();
alert(
    `My Name Is ${data.fullname}. My Mobile Number Is ${data.phone}. My Email Address Is ${data.email}, Here Is What I Want To Say ${data.message}`);
};
    return( 
    <>

<div className="my-5 text-center">
    <h1>Contact US</h1>
</div>
<div className="container container_div">
    <div className="row">
        <div className="col-md-6 col-10 mx-auto">
        <form onSubmit={formSubmit}>
  <div className="form-group">
    <label for="exampleFromControlInput1">Full Name</label>
    <input type="text" className="form-control" id="exampleInputName" aria-describedby="emailHelp" name="fullname" value={data.fullname} onChange={InputEvent} placeholder="Enter Your Full Name" required/>
  </div>  
  <div className="form-group">
    <label for="exampleFromControlInput1">Phone</label>
    <input type="number" className="form-control" id="exampleInputPhone" name="phone" value={data.phone} onChange={InputEvent} placeholder="Enter Your Phone" required />
  </div>
  <div className="form-group">
    <label for="exampleFromControlInput1">Email Address</label>
    <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" value={data.email} onChange={InputEvent} placeholder="Enter Your Email" required/>
  </div>
  <div className="form-group">
    <label for="exampleFromControlInput1">Example textarea</label>
    <textarea className="form-control" id="exampleFormControlTextarea1" rows="3" name="message" value={data.message} onChange={InputEvent} placeholder="Enter Your Message" required></textarea>
  </div>

  <button className="btn btn-outline-primary">Submit</button>
</form>  
        </div>
    </div>
</div>
    </>
    );
    };
export default Contact;