// import * as firebase from 'firebase/app';
// import 'firebase/database';
// import 'firebase/auth';