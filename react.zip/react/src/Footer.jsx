import React from 'react';

const Footer = () => {
    return(
        <>
        <footer className="footer text-center">
            <p>© 2020, Technical Muzammil . All Right Reserved | Terms And Condition </p>
        </footer>
        </>
    )
}
export default Footer;